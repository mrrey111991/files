wildcard url pattern 
http://support.google.com/customsearch/bin/answer.py?hl=en&answer=71826
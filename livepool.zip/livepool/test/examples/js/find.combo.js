function(){
    return true;
}
function(){
    // updated 2
    return true;
}
function(){
    return true;
}
### liveapp is web gui for livepool

bug to fix: liveapp must not be visited through livepool proxy port(8000), must visit directly.
This is a copy of qtest (https://qtest.sourceforge.io) which is distributed
under the terms of the Artistic license and has the same author as
qpdf.

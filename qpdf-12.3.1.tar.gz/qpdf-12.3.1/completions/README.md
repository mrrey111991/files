These completion files may be installed in your system's vendor completion area for bash and zsh.

For example, on a debian-based system, you could install these as

```
cp bash/qpdf /usr/share/bash-completion/completions/
cp zsh/_qpdf /usr/share/zsh/vendor-completions/
```

Packagers are encouraged to install these in whatever locations appropriate for their systems.
